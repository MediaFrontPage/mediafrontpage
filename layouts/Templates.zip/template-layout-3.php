<?php
$arrLayout = array(
		"section1" => array(
		),
		"section2" => array(
		),
		"section3" => array(
		)
	);
?>
